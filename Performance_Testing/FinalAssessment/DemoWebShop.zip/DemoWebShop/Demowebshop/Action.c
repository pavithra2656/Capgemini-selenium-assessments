Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

/*Correlation comment - Do not change!  Original value='141-inch-laptop' Name ='C_product' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_product",
		"RegExp=a\\ href=\"/(.*?)\"\\ title",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	web_concurrent_start(NULL);

	web_url("styles.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.css", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("jquery.validate.unobtrusive.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.unobtrusive.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("responsive.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/responsive.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("nivo-slider.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/nivo-slider.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("default.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("jquery-1.10.2.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-1.10.2.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("jquery.validate.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-ui-1.10.3.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("jquery-migrate-1.2.1.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-migrate-1.2.1.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("public.common.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.common.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("public.ajaxcart.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.ajaxcart.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("jquery.nivo.slider.js", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Scripts/jquery.nivo.slider.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("0000215.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000215.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("0000240.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("0000031_build-your-own-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000031_build-your-own-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("0000204_simple-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000204_simple-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("0000201_build-your-own-expensive-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000201_build-your-own-expensive-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("0000015_25-virtual-gift-card_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000015_25-virtual-gift-card_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_125.png",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_{C_product}_125.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t28.inf",
		LAST);

	web_url("favicon.ico", 
		"URL=https://demowebshop.tricentis.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t30.inf", 
		LAST);

	web_concurrent_end(NULL);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_concurrent_start(NULL);

	web_url("top-menu-divider.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("loading.gif", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("bullet-right.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/bullet-right.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("star-x-inactive.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("star-x-active.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t25.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(9);

	web_url("ui-bg_flat_75_ffffff_40x100.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t29.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("arrows.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("bullets.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t32.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(10);

	lr_start_transaction("1_register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("top-menu-triangle.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t34.inf", 
		LAST);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=bfqaSew4oDCjkPpM6mt5JljDBJ-DS-maFDbKUjS38crvC_4ZDelIiN4j5QcBRMSwMXDJqAseoL0JhCe_46vnfEUS7fAoSVv4YpZKVxEUg8A1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value={P_fname}", ENDITEM, 
		"Name=LastName", "Value={P_lname}", ENDITEM, 
		"Name=Email", "Value={P_email}", ENDITEM, 
		"Name=Password", "Value={P_password}", ENDITEM, 
		"Name=ConfirmPassword", "Value={P_cpassword}", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t36.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("1_register",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("2_selectproduct");

	web_websocket_close("ID=0", 
		"Code=1000", 
		LAST);

	lr_think_time(19);

	web_url("14.1-inch Laptop",
		"URL=https://demowebshop.tricentis.com/{C_product}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t37.inf",
		"Mode=HTTP",
		LAST);

	web_concurrent_start(NULL);

	web_url("magnific-popup.css",
		"URL=https://demowebshop.tricentis.com/Content/magnific-popup/magnific-popup.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t38.inf",
		LAST);

	web_url("jquery.magnific-popup.js",
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.magnific-popup.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t39.inf",
		LAST);

	web_url("0000224_141-inch-laptop_300.png",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_{C_product}_300.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t40.inf",
		LAST);

	web_concurrent_end(NULL);

	web_websocket_send("ID=1", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive1*/

	lr_end_transaction("2_selectproduct",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("3_addtocart");

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t41.inf", 
		LAST);

	web_submit_data("1",
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/31/1",
		"Method=POST",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t42.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=addtocart_31.EnteredQuantity", "Value=1", ENDITEM,
		LAST);

	web_concurrent_start(NULL);

	web_url("ico-close-notification-bar.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t43.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_47.png",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_{C_product}_47.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t44.inf",
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("3_addtocart",LR_AUTO);

	lr_think_time(39);

	lr_start_transaction("4_shoppingcart");

	web_url("cart",
		"URL=https://demowebshop.tricentis.com/cart",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_product}",
		"Snapshot=t45.inf",
		"Mode=HTTP",
		LAST);

	web_websocket_close("ID=1", 
		"Code=1000", 
		LAST);

	web_url("0000224_141-inch-laptop_80.png",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_{C_product}_80.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://demowebshop.tricentis.com/cart",
		"Snapshot=t46.inf",
		LAST);

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive2*/

	lr_end_transaction("4_shoppingcart",LR_AUTO);

	lr_start_transaction("5_checkout");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t47.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7121952", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("public.onepagecheckout.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.onepagecheckout.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t48.inf", 
		LAST);

	web_url("public.accordion.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.accordion.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t49.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("5_checkout",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("6_billing");

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t50.inf", 
		LAST);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=91&addEmptyStateIfRequired=true&_=1790850101298", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t51.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(8);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t52.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={P_fname}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={P_lname}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value={P_email}", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=91", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value={P_city}", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value={P_addr1}", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value={P_addr2}", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value={P_zipcode}", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value={P_phno}", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_url("arrow-up.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/arrow-up.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t53.inf", 
		LAST);

	lr_end_transaction("6_billing",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("7_shipaddr");

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t54.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159924", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_fname}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value={P_lname}", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_email}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("7_shipaddr",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("8_shipmethod");

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo.jpg", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CashOnDelivery/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("logo.jpg_2", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CheckMoneyOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("logo.jpg_3", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.Manual/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t58.inf", 
		LAST);

	web_url("logo.jpg_4", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.PurchaseOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t59.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("8_shipmethod",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("9_paymethod");

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t60.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	lr_end_transaction("9_paymethod",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("10_payinfo");

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t61.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("10_payinfo",LR_AUTO);

	lr_start_transaction("11_confirm");

	web_websocket_close("ID=2", 
		"Code=1000", 
		LAST);

	web_websocket_send("ID=3", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 3 received buffer WebSocketReceive3*/

	lr_think_time(13);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("11_confirm",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("12_continue");

	web_url("Tricentis Demo Web Shop_2", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/checkout/completed/", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0000224_141-inch-laptop_32.png",
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_{C_product}_32.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t65.inf",
		LAST);

	lr_end_transaction("12_continue",LR_AUTO);

	return 0;
}